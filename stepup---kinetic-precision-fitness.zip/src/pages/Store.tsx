import React, { useState } from 'react';
import { motion } from 'motion/react';

export default function Store() {
  const [selectedColor, setSelectedColor] = useState('primary');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start"
    >
      {/* Visualizer Canvas (Left) */}
      <div className="lg:col-span-7 sticky top-24">
        <div className="relative w-full aspect-[4/3] rounded-3xl bg-surface-container-low overflow-hidden group border border-white/5 shadow-2xl">
          <div className="absolute inset-0 bg-gradient-to-br from-secondary/5 to-transparent opacity-50"></div>
          {/* Dynamic Labeling */}
          <div className="absolute top-8 left-8 z-10">
            <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border border-primary/20">定制实验室 v2.0</span>
            <h1 className="font-headline text-5xl font-black text-on-surface mt-4 leading-none tracking-tighter uppercase">
              KINETIC<br /><span className="text-secondary">PHANTOM</span>
            </h1>
          </div>
          {/* Main Shoe Image */}
          <div className="absolute inset-0 flex items-center justify-center shoe-glow">
            <motion.img
              key={selectedColor}
              initial={{ scale: 0.8, rotate: -20, opacity: 0 }}
              animate={{ scale: 1, rotate: -12, opacity: 1 }}
              className="w-4/5 h-auto object-contain transform transition-transform duration-700 ease-out group-hover:rotate-0"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBRxTgHGPlNLjn0pHs3Yz3YgvqIv_Qj1qhSik8XbUp9hlrQBTYYjui39GnKjADRk0JQvZGgXTDqYrobJZALsaGRwb5QGE6yg-fbb_jmxjPCJUvzYQWI-G7u26nk6h69Yj5YTJ0nd-iejVj-f_R8evFw6nNasyPbzuX-Nsil_Eubms-zTLsni9fSCAwAw2Qy26S6MzuA3afHxMBZGfxxTKdCutA251_-zIER80dEsiXerT-oJRUnMYR0Pvc2ZpHdJmCs-0J3bRTRYT3Q"
            />
          </div>
          {/* Floating Metric Cards */}
          <div className="absolute bottom-8 right-8 flex flex-col gap-3">
            <div className="bg-surface-container-high/80 backdrop-blur-md p-3 rounded-2xl border border-outline-variant/20 flex items-center gap-3">
              <span className="material-symbols-outlined text-secondary fill-1">bolt</span>
              <div>
                <p className="text-[10px] text-on-surface-variant uppercase font-bold">能量回馈</p>
                <p className="text-lg font-headline font-bold text-primary">98.4%</p>
              </div>
            </div>
            <div className="bg-surface-container-high/80 backdrop-blur-md p-3 rounded-2xl border border-outline-variant/20 flex items-center gap-3">
              <span className="material-symbols-outlined text-secondary fill-1">weight</span>
              <div>
                <p className="text-[10px] text-on-surface-variant uppercase font-bold">整体重量</p>
                <p className="text-lg font-headline font-bold text-primary">184g</p>
              </div>
            </div>
          </div>
        </div>
        {/* Thumbnails/Angles */}
        <div className="mt-6 flex gap-4 overflow-x-auto hide-scrollbar pb-2">
          {[
            "https://lh3.googleusercontent.com/aida-public/AB6AXuBhIyFUX5PLXImggqvZSneD3ztmOy6dhY8Q2gqGUQzA83L79pbu09C_xxYm7TskDSOcEq-UcVxibJmerj6gLdDBCDEXOZsjzRsPEQyOTN_Uf9bGqRNcD-8qvMtRmUAYbe38EHDY4yXXsB8EegnvgeAYStXKQzk9oejvWO_uRi5ueNREwTYF6fuudDwEwJPi0CLz5SAh2UoirwJoRJP1xvjt3pGHx32Jz1JFNmrON_-YyOrzCF7NA_5NGa0JjbGeLt_zoUGXMSTy8UoY",
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDx6kJpXUdB95NgoAUfwvTDZlrvNPOLvP4c8z3XRx-dJ676_NSdvs7V9GPVKiuqOmmxUUtT7ey0-N2106Qg2kxoJ_LnlA6BJp26PzRTLcuuQIpL8lity3Iis5YHOS3TRjuz9e4mpGHnxOi0sBGxkUc3YU6D_tgiMXwev_HRDqZ9uA5yxSzpzvRimUBYSoxBTOYowwDedryu_rsNuaFykdVAaaSUoGgE07UDUO75kR7tKC-2IOvejqzbofk9oGb2fZvw9DY0GH79KR4E",
            "https://lh3.googleusercontent.com/aida-public/AB6AXuC6i3nCdfEWLzullEs7exZdi4U0eoOgHm_gAsZw4p-vV3UnZDZ00_SdRNEr0k6Bq8GEj-BPeuARymGLwIFafs-mgadRP1py_uwkWuo7DBTpbo-9TJqie1k8u_BfOMTEkbi5BNUQT3ZsGpFVWL7M7MkxWaQKoYWpWXJfJ0ehW4Y4jUX092XkmczAzuexewluVg6T0LID8FAWwYv50luM78ReP98jPst9Mv_JnvGt5HSPpbE01-09p_Wf_AfYKvAtDKrJTNDafgMHwOab"
          ].map((src, i) => (
            <button key={i} className={cn("flex-shrink-0 w-24 h-24 rounded-xl bg-surface-container-low overflow-hidden border-2 transition-all", i === 0 ? "border-primary" : "border-transparent opacity-60 hover:opacity-100")}>
              <img className="w-full h-full object-cover" src={src} />
            </button>
          ))}
        </div>
      </div>

      {/* Customization Panel (Right) */}
      <div className="lg:col-span-5 flex flex-col gap-8">
        <section>
          <div className="flex justify-between items-baseline mb-4">
            <h2 className="font-headline text-xl font-bold uppercase tracking-tight">配置定制</h2>
            <span className="text-on-surface-variant text-sm font-sans">StepID: 8842-PX</span>
          </div>
          {/* Chassis Material Selection */}
          <div className="bg-surface-container-low p-6 rounded-3xl border border-white/5 mb-6">
            <p className="text-xs font-bold text-secondary uppercase tracking-[0.2em] mb-4">鞋底材质</p>
            <div className="grid grid-cols-3 gap-3">
              {[
                { name: '碳纤维', icon: 'hexagon', active: true },
                { name: '再生网面', icon: 'grid_view' },
                { name: '生物编织', icon: 'gesture' },
              ].map((mat) => (
                <button key={mat.name} className={cn("flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all", mat.active ? "bg-surface-container-highest border-primary ring-1 ring-primary/30" : "bg-surface-container border-outline-variant/20 hover:bg-surface-container-highest")}>
                  <span className={cn("material-symbols-outlined", mat.active ? "text-primary" : "text-on-surface-variant")}>{mat.icon}</span>
                  <span className="text-[10px] font-bold uppercase">{mat.name}</span>
                </button>
              ))}
            </div>
          </div>
          {/* Traction Pattern */}
          <div className="bg-surface-container-low p-6 rounded-3xl border border-white/5 mb-6">
            <p className="text-xs font-bold text-secondary uppercase tracking-[0.2em] mb-4">抓地纹路</p>
            <div className="grid grid-cols-3 gap-3">
              {['竞速', '稳定', '全地形'].map((p) => (
                <button key={p} className={cn("px-3 py-2 rounded-xl border text-[10px] font-bold uppercase transition-all", p === '稳定' ? "bg-surface-container border-primary text-primary" : "bg-surface-container-highest border-outline-variant/30")}>
                  {p}
                </button>
              ))}
            </div>
          </div>
          {/* Color Zones */}
          <div className="bg-surface-container-low p-6 rounded-3xl border border-white/5 mb-6 space-y-6">
            <div>
              <p className="text-xs font-bold text-secondary uppercase tracking-[0.2em] mb-4">鞋面颜色</p>
              <div className="flex flex-wrap gap-3">
                {[
                  { id: 'primary', color: 'bg-primary' },
                  { id: 'secondary', color: 'bg-secondary' },
                  { id: 'error', color: 'bg-error' },
                  { id: 'dark', color: 'bg-surface-container-highest' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedColor(c.id)}
                    className={cn(
                      "w-8 h-8 rounded-full transition-all",
                      c.color,
                      selectedColor === c.id ? "ring-offset-4 ring-offset-background ring-2 ring-primary" : "border border-outline-variant/30"
                    )}
                  />
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-3">后跟支撑</p>
                <div className="flex gap-2">
                  <button className="w-6 h-6 rounded-full bg-[#1e1e1e] border border-outline-variant/30 ring-2 ring-offset-2 ring-offset-background ring-primary"></button>
                  <button className="w-6 h-6 rounded-full bg-primary"></button>
                  <button className="w-6 h-6 rounded-full bg-secondary"></button>
                </div>
              </div>
              <div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-3">中底点缀</p>
                <div className="flex gap-2">
                  <button className="w-6 h-6 rounded-full bg-secondary"></button>
                  <button className="w-6 h-6 rounded-full bg-primary border border-outline-variant/30 ring-2 ring-offset-2 ring-offset-background ring-primary"></button>
                  <button className="w-6 h-6 rounded-full bg-white"></button>
                </div>
              </div>
            </div>
          </div>
          {/* Points Discount Toggle */}
          <div className="bg-secondary/5 p-6 rounded-3xl border border-secondary/20 flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-secondary fill-1">offline_bolt</span>
              </div>
              <div>
                <p className="text-sm font-bold">使用能量值</p>
                <p className="text-[10px] text-secondary font-bold uppercase">余额: 14,200 EP</p>
              </div>
            </div>
            <button className="w-12 h-6 bg-secondary rounded-full relative p-1 transition-colors active:scale-95">
              <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-[0_0_8px_rgba(255,255,255,0.6)]"></div>
            </button>
          </div>
        </section>

        {/* Final Pricing & CTA */}
        <div className="mt-auto pt-6 border-t border-outline-variant/10">
          <div className="space-y-2 mb-6">
            <div className="flex justify-between text-sm">
              <span className="text-on-surface-variant">基础配置</span>
              <span className="text-on-surface">$240.00</span>
            </div>
            <div className="flex justify-between text-sm text-secondary font-bold">
              <div className="flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">remove_circle_outline</span>
                <span>能量值抵扣 (10,000 EP)</span>
              </div>
              <span>-$55.00</span>
            </div>
            <div className="pt-4 flex justify-between items-end">
              <div>
                <p className="text-[10px] text-on-surface-variant uppercase font-bold tracking-widest">总价</p>
                <span className="text-on-surface text-4xl font-headline font-black italic">$185.00</span>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-error font-bold uppercase">限量发售</p>
                <p className="text-on-surface-variant text-sm">剩余 48 双</p>
              </div>
            </div>
          </div>
          <button className="w-full kinetic-gradient text-[#3a4a00] py-5 rounded-full font-headline font-black text-lg uppercase tracking-tight flex items-center justify-center gap-2 shadow-[0_12px_48px_rgba(202,253,0,0.2)] active:scale-[0.98] transition-all">
            完成定制并加入购物车
            <span className="material-symbols-outlined font-bold">trending_flat</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
