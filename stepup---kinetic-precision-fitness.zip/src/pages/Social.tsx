import React from 'react';
import { motion } from 'motion/react';

export default function Social() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-12"
    >
      {/* Comparison Tool Section */}
      <section>
        <div className="flex justify-between items-end mb-6">
          <div>
            <h2 className="text-4xl font-headline font-black tracking-tight text-primary uppercase">对手动态</h2>
            <p className="text-on-surface-variant">步数对比</p>
          </div>
          <button className="flex items-center gap-2 text-secondary font-bold text-sm bg-secondary/10 px-4 py-2 rounded-full border border-secondary/20 active:scale-95 transition-all">
            <span className="material-symbols-outlined text-sm">add</span> 添加对手
          </button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Comparison Chart */}
          <div className="lg:col-span-2 bg-surface-container-low rounded-xl p-6 relative overflow-hidden border border-white/5">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <span className="material-symbols-outlined text-9xl">equalizer</span>
            </div>
            <div className="flex gap-4 mb-8">
              {[
                { label: '你', color: 'bg-primary', border: 'border-primary/20' },
                { label: 'Alex M.', color: 'bg-secondary', border: 'border-secondary/20' },
                { label: 'Sarah K.', color: 'bg-error', border: 'border-error/20' },
              ].map((item) => (
                <div key={item.label} className={cn("flex items-center gap-2 bg-surface-container-high px-3 py-1 rounded-full border", item.border)}>
                  <div className={cn("w-2 h-2 rounded-full", item.color)}></div>
                  <span className="text-xs font-bold">{item.label}</span>
                </div>
              ))}
            </div>
            {/* Visual Comparison */}
            <div className="flex items-end justify-between h-48 gap-4 px-4">
              {[
                { day: '周一', val: '85%' },
                { day: '周二', val: '92%' },
                { day: '周三', val: '60%' },
                { day: '周四', val: '75%' },
                { day: '周五', val: '88%', active: true },
              ].map((bar) => (
                <div key={bar.day} className="flex flex-col items-center flex-1">
                  <div className="w-full bg-surface-container-highest rounded-t-lg relative h-40">
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: bar.val }}
                      className={cn(
                        "absolute bottom-0 w-full rounded-t-lg transition-all",
                        bar.active ? "bg-gradient-to-t from-primary to-primary-container shadow-[0_0_24px_rgba(243,255,202,0.3)]" : "bg-gradient-to-t from-primary/50 to-primary/80"
                      )}
                    />
                  </div>
                  <span className={cn("mt-2 text-[10px] font-bold uppercase", bar.active ? "text-primary" : "text-on-surface-variant")}>
                    {bar.day}
                  </span>
                </div>
              ))}
            </div>
          </div>
          {/* Comparison Summary */}
          <div className="bg-surface-container-low rounded-xl p-6 flex flex-col justify-between border-l-4 border-secondary shadow-xl">
            <div>
              <p className="text-xs font-bold text-on-surface-variant uppercase tracking-widest mb-2">领先指数</p>
              <h3 className="text-5xl font-headline font-black text-secondary leading-tight">+14%</h3>
              <p className="text-sm text-on-surface-variant mt-2">你今天领先 Alex M. <span className="text-on-surface font-bold">1,240 步</span>。</p>
            </div>
            <div className="mt-8">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                <span className="text-xs font-bold uppercase">实时领先</span>
              </div>
              <div className="flex -space-x-3">
                {[
                  "https://lh3.googleusercontent.com/aida-public/AB6AXuBRLZEyuZTWoGOqSn6mtbA6-fduonP60qrTyHxCYrwYyGNtw3HoxmaEyo_iVKt3yKbeDX1mIkBrMRIs3N4edPPBG32fsKafPMUhnvAe3ImmlJa_XaUxSpuZcXTWyKuoBEnRsOEF9qB2MeNv-AhcY9esk30PveQ7QXlha_jefbAW9VUJQ-ujRYSHPHLae3I_fCVAuE8PkmS50-EbhYNHHwCeXR-b16gLN0dE1w-38oJkQxacd4vBEHZ_6HnIaHncKA2SqEwbzTHFrRuh",
                  "https://lh3.googleusercontent.com/aida-public/AB6AXuDgVSO0kxo7ECPobYc4hQVRKM5JIsxc1W60MH57H2B0VV9puHBxHnX2dxArmOQt9Xhj2VZy8lhzhKQZ5v-ZXoYK6GHS_g1wAQ9jVW6HK6Vockf3qq9R5nw6nukjFZnSv9TQv3hI4DiHMX4NJ3_mDP7cNHUk_h75DGav_LFQD_7amhlVIMP2DE-sDDa5uQSuuTre4jM9AWMF7DUJ2WsOM7HwTImDR3yuVEYNw3tA-5CUY-LInX66xQ7eKDDQTZ338itLCvbS7Qn2LvVJ"
                ].map((src, i) => (
                  <img key={i} alt="Friend" className="w-10 h-10 rounded-full border-2 border-surface-container-low" src={src} />
                ))}
                <div className="w-10 h-10 rounded-full bg-surface-container-highest border-2 border-surface-container-low flex items-center justify-center text-[10px] font-bold">+5</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leaderboard & Social Feed Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
        {/* Leaderboards */}
        <div className="xl:col-span-7 space-y-8">
          <div className="flex gap-4 border-b border-outline-variant/20 pb-4">
            <button className="text-lg font-headline font-bold text-primary relative">
              全球
              <div className="absolute -bottom-[17px] left-0 w-full h-1 bg-primary"></div>
            </button>
            <button className="text-lg font-headline font-bold text-on-surface-variant hover:text-on-surface transition-colors">好友</button>
            <button className="text-lg font-headline font-bold text-on-surface-variant hover:text-on-surface transition-colors">俱乐部</button>
          </div>
          <div className="space-y-4">
            {[
              { rank: '01', name: "Marcus 'Bolt' Chen", desc: '职业运动员 • 纽约', val: '24,892', img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDivdZXyjYCxlmW7w6YRcgCg8ufONEgFBlAsLpC8cvo817UFB1lkyfV_BJRnLcV5pYkKJTrpNz52FZA5pFYZBRUfy6pVkw7KKrewIyOoLyGYHG2P0hUXWVobXtOeVoEiNQGWYoC_nd3ph70C6zJ6YEBz1vcoXGpAXk1xHSLjPxbT7M-E8X8HmTOjl7MbevOYdCmmYyGdRLJV0bAWp_HxHQWux4IHoOpHbJtmDZr3s6EXc-CEeU_fyM3MtrlDB_gjyhTy3s9vzLitbS4", active: true },
              { rank: '02', name: "Elena Rodriguez", desc: '马拉松选手 • 马德里', val: '21,405', img: "https://lh3.googleusercontent.com/aida-public/AB6AXuCDW-eFP-ET5cmMYRuQrKOovqMqZIQzAkHtRXKZuhboLJ0LHK4ElDSIq0GCr37XIg49wjJiODBLc7jJTUrs_bme4ckiLbOyIDc6bukkHWsnmkOC01GG_amwA1cSY8O0_-nvzzR5x2bgU-YPHkBiGq8Vwb40lcAjGzQdCKRs8TOE0Op1zTfOMqydsRKwrhW-aWTGnkfFh-FX9MkNBnmfK2IqP6J7zFrMSNjjoBgRtll48evqKlgd6spkRtuA7dkfpnMTQ5DbiL_oxy09" },
              { rank: '03', name: "Jameson V.", desc: '越野跑者 • 奥斯陆', val: '19,880', img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDhiIKJGvQ4j5AUDTkY2msokivdXScP-OvhBs5o6dObV4l8I2Itqb02o-JoPS1R08nGM8CFC8h6x4ZqShpV88FYm_NngTfpZ1i5Fo32q8DaTuv4lkuu9gyX1EMhCLroVu6_CAGk8F4z6n8EZ_lCZlPBLrgRyVkS8943ltnNyJjD2OfC-wZArwR6XiM8Aak0LB7Y8gVEvKLSzg1mf_txgwKzgufzCDovF8XIyLS7eb938cM48M9v5ZZIDx5f3y0g83FhMMwRnh8aVYqk" },
            ].map((user) => (
              <div key={user.rank} className={cn("bg-surface-container-low rounded-xl p-4 flex items-center gap-6 border border-white/5 transition-all", user.active && "bg-surface-container-highest border-l-4 border-primary translate-x-2")}>
                <span className={cn("text-2xl font-headline font-black italic w-8", user.active ? "text-primary" : "text-on-surface-variant")}>{user.rank}</span>
                <img alt={user.name} className="w-14 h-14 rounded-full" src={user.img} />
                <div className="flex-1">
                  <h4 className="font-headline font-bold text-on-surface">{user.name}</h4>
                  <p className="text-xs text-on-surface-variant font-bold uppercase">{user.desc}</p>
                </div>
                <div className="text-right">
                  <p className={cn("text-xl font-headline font-black", user.active ? "text-primary" : "text-on-surface")}>{user.val}</p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold tracking-widest">今日步数</p>
                </div>
              </div>
            ))}
            {/* User's Rank Pin */}
            <div className="bg-secondary/10 border border-secondary/20 rounded-xl p-4 flex items-center gap-6 mt-8 shadow-lg">
              <span className="text-2xl font-headline font-black text-secondary italic w-8">42</span>
              <img alt="User" className="w-14 h-14 rounded-full border-2 border-secondary" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBQ8gz5hZdShcDTghlOkPRpXAT3plL5zgQNVkapHVf1P-Pjak3rU5evV8Akn6a_rl1SkGASWcGcE83bQs7QFq0qoVWXnPCY92wQoGlp8BRWWeGmx5Yub3-X-X5IHqnMU9Q1OVxGpN_smoJseeH2jF9x_0TrJwgs4BLi6a6XEaZ7aCqAqhU96unWq2Z5DFNtrM9kGbRKINo1BrGK_e3wwCtONclx45kJSla0mG6adIVWYmmESzX5gVlnMefFTtNNtmz4ZoQxivf1eh8Q" />
              <div className="flex-1">
                <h4 className="font-headline font-bold text-on-surface">你 (运动员)</h4>
                <p className="text-xs text-secondary font-bold uppercase">挑战者 • 等级 42</p>
              </div>
              <div className="text-right">
                <p className="text-xl font-headline font-black text-secondary">12,450</p>
                <p className="text-[10px] text-on-surface-variant uppercase font-bold tracking-widest">今日步数</p>
              </div>
            </div>
          </div>
        </div>
        {/* Social Feed */}
        <div className="xl:col-span-5 space-y-8">
          <h3 className="text-2xl font-headline font-black tracking-tight text-on-surface uppercase italic">动态广场</h3>
          <div className="space-y-6">
            {/* Achievement Card */}
            <div className="bg-surface-container-low rounded-xl overflow-hidden border border-white/5 shadow-xl">
              <div className="p-4 flex items-center gap-3">
                <img alt="Friend" className="w-10 h-10 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCJIMYY3ZNAcYkpxxK-tc5EUyhrvP7gc2hZm2ORxLsUhDKxbpTggpYdkjP4o3uOCfy_l4RSpdrhSMkIm1HUZmm-Fd6L4-37RlbCJOwrkSUQtVW4xQgFPYCvqLgAdjIda2oIQZJOfAsM4bwVcN4IX739IDxRait-YC_59unHec1YDmT81yGV-2PApgaO_XWemlUB-j2ZF1i8vabwFzUIhizGcJo-KKnUZPdBC_T1CugZJ0tML_Okp-N67Qn7umyQoguWmq8zi-AY8JXs" />
                <div className="flex-1">
                  <p className="text-sm font-sans"><span className="font-bold text-on-surface">Sarah K.</span> 解锁了 <span className="text-primary font-bold">铁肺</span> 成就</p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold">2 小时前</p>
                </div>
                <span className="material-symbols-outlined text-tertiary fill-1">workspace_premium</span>
              </div>
              <div className="h-48 w-full bg-cover bg-center grayscale hover:grayscale-0 transition-all duration-500" style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAexg5issnxE4y1f2_Kt1X14A43HLu00WgB5yY6vniFHEQncu3XiJBglk3aAvCcZZO8kUBdxrwNbeeSnRMQCjlOM4PNbl7CejCvwHvkM-gzFIEcMyrCXLULWIBVK_wMoWNFh7Se8hlMG6TTfOEwiNoUUQ-Lqvjt1ElOmBPFWucCtsZKw_op6i9fAnkicLjsMV5RLugGMtRSsIni4SzmfJmUp_N1khWoK8pjWWQ_aJh91_KakubEdSI0KEElcFfwQWnrih56gj4bsswC')" }}>
              </div>
              <div className="p-4 flex justify-between items-center bg-surface-container-high/50">
                <div className="flex gap-4">
                  <button className="flex items-center gap-1 text-xs font-bold text-on-surface-variant hover:text-error transition-colors"><span className="material-symbols-outlined text-sm fill-1">favorite</span> 24</button>
                  <button className="flex items-center gap-1 text-xs font-bold text-on-surface-variant hover:text-secondary transition-colors"><span className="material-symbols-outlined text-sm">chat_bubble</span> 3</button>
                </div>
                <span className="text-[10px] font-bold text-on-surface-variant uppercase bg-surface-container px-2 py-1 rounded">5.2 公里 跑步</span>
              </div>
            </div>
            {/* Activity Card */}
            <div className="bg-surface-container-low rounded-xl p-4 border border-white/5 shadow-xl">
              <div className="flex items-center gap-3 mb-3">
                <img alt="Friend" className="w-10 h-10 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBTHxP4kqxqNijfe4QLHfQXBcxI45t5u2UFMF-RyjlhGHvzgPXN8QLkH1ivjLsnvi30_Z_7Qp4Gif5kisT8AjzK8fYTER_9lNMGM55U7y5-3J6_lEFpnH_B_2QGo6PbIuXKZbE0mpFJTYXfNqBivhXfcUkoa9Ea-j8pNJY-uo4If5o0aahBZZ8-a8YXbs1cHQ2preie2KvNS3SrJ-cUX45_XBYdirdkvF_eGnoq8T0g3UsTNTSwhojNrmRXFrUwj2s70flLqqxsabXe" />
                <div className="flex-1">
                  <p className="text-sm font-sans"><span className="font-bold text-on-surface">Alex M.</span> 完成了 <span className="text-secondary font-bold">晨间冲刺</span></p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold">4 小时前</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: '步数', val: '8.4k' },
                  { label: '时长', val: '42分' },
                  { label: '配速', val: "5'12\"" },
                ].map((stat) => (
                  <div key={stat.label} className="bg-surface-container p-2 rounded-lg text-center">
                    <p className="text-[10px] text-on-surface-variant font-bold uppercase">{stat.label}</p>
                    <p className="font-headline font-bold text-on-surface">{stat.val}</p>
                  </div>
                ))}
              </div>
              <button className="w-full mt-4 py-2 border border-outline-variant/30 rounded-full text-xs font-bold uppercase hover:bg-white/5 transition-colors active:scale-95">为 Alex 加油</button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
