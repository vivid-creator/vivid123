import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/src/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();

  const navItems = [
    { name: '仪表盘', path: '/', icon: 'speed' },
    { name: '社交', path: '/social', icon: 'leaderboard' },
    { name: '商店', path: '/store', icon: 'storefront' },
    { name: '个人主页', path: '/profile', icon: 'account_circle' },
  ];

  return (
    <div className="min-h-screen bg-background text-on-surface font-sans selection:bg-primary selection:text-on-primary-container">
      {/* Top Bar */}
      <header className="fixed top-0 w-full z-50 bg-[#0c0e11]/70 backdrop-blur-xl shadow-[0_0_48px_rgba(0,227,253,0.06)] flex justify-between items-center px-6 py-4">
        <div className="flex items-center gap-8">
          <span className="text-2xl font-black italic text-primary font-headline tracking-tight">StepUp</span>
          <nav className="hidden md:flex gap-6 items-center">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  cn(
                    "font-headline tracking-tight transition-colors",
                    isActive ? "text-primary font-bold" : "text-on-surface-variant hover:text-secondary"
                  )
                }
              >
                {item.name}
              </NavLink>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex bg-surface-container-high rounded-full px-4 py-1.5 items-center gap-2 border border-outline-variant/15">
            <span className="material-symbols-outlined text-secondary text-sm">search</span>
            <input
              className="bg-transparent border-none focus:ring-0 text-sm w-32 placeholder:text-on-surface-variant/50"
              placeholder="查找装备..."
              type="text"
            />
          </div>
          <button className="text-primary hover:text-secondary transition-colors active:scale-95 duration-200">
            <span className="material-symbols-outlined">shopping_cart</span>
          </button>
          <button className="text-primary hover:text-secondary transition-colors active:scale-95 duration-200">
            <span className="material-symbols-outlined">notifications</span>
          </button>
        </div>
      </header>

      <div className="flex pt-20">
        {/* Sidebar (Desktop) */}
        <aside className="hidden md:flex flex-col py-8 h-[calc(100vh-80px)] w-64 border-r border-secondary/15 bg-[#0c0e11] sticky top-20">
          <div className="px-6 mb-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary">
                <img
                  alt="运动员"
                  className="w-full h-full object-cover"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBPVR9M8G87tt9SEBVhGiRnoYWlEm5BWLg9fX6R1OzHUz1OS2OZXPRS08mlYNiFLL-5vRpwf07YnC3paXo-ZW1mUcb-gqKMQ0YU0cE1mMzeLpPJG5iIAuaNvhEeOtgv0Ou_sFkuZscaFHSEphSNNwgUDc4zZf_FFbUHkraBMn98GC7L_ht74zjafq_h23K82FsC0oTcS3i3skrqvBebwMsPQX1XM2eawyRU4kcJcs4P2eUQN61mlFp_3M2YwlZ-LRak8MyXh_kyMvyb"
                />
              </div>
              <div>
                <p className="font-headline font-black text-primary leading-tight">运动员</p>
                <p className="text-xs text-on-surface-variant uppercase font-bold tracking-widest">等级 42</p>
              </div>
            </div>
          </div>
          <nav className="flex-1 space-y-2">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-4 py-3 mx-2 rounded-full transition-all active:translate-x-1",
                    isActive
                      ? "kinetic-gradient text-[#0c0e11] font-bold shadow-[0_0_24px_rgba(243,255,202,0.2)]"
                      : "text-on-surface-variant hover:text-on-surface hover:bg-white/5"
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    <span className={cn("material-symbols-outlined", isActive && "fill-1")}>{item.icon}</span>
                    <span className="font-sans font-bold">{item.name}</span>
                  </>
                )}
              </NavLink>
            ))}
          </nav>
          <div className="px-4 mt-auto">
            <button className="w-full kinetic-gradient text-[#3a4a00] font-headline font-black py-4 rounded-full shadow-[0_0_32px_rgba(202,253,0,0.2)] active:scale-95 duration-200 uppercase tracking-tight">
              开始训练
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-10 pb-32 md:pb-10">
          {children}
        </main>
      </div>

      {/* Bottom Nav (Mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full flex justify-around items-center px-4 pb-6 pt-3 bg-[#0c0e11]/70 backdrop-blur-2xl z-50 rounded-t-[24px] shadow-[0_-8px_32px_rgba(0,0,0,0.4)]">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                "flex flex-col items-center justify-center p-2 active:scale-90 transition-transform duration-150",
                isActive ? "text-primary bg-primary/10 rounded-2xl px-4" : "text-on-surface-variant"
              )
            }
          >
            {({ isActive }) => (
              <>
                <span className={cn("material-symbols-outlined", isActive && "fill-1")}>{item.icon}</span>
                <span className="text-[10px] font-bold uppercase tracking-widest mt-1">{item.name}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
