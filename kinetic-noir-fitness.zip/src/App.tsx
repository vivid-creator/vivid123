/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { 
  Activity, 
  Flame, 
  Heart, 
  Trophy, 
  ShoppingBag, 
  TrendingUp, 
  User, 
  Search,
  ChevronRight,
  Plus
} from "lucide-react";

const Nav = () => (
  <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-outline-variant px-6 py-4 flex items-center justify-between">
    <div className="flex items-center gap-8">
      <h1 className="font-display text-2xl font-bold tracking-tighter text-primary">KINETIC.</h1>
      <div className="hidden md:flex gap-6 text-sm font-medium text-white/60">
        <a href="#" className="text-white hover:text-primary transition-colors">Dashboard</a>
        <a href="#" className="hover:text-primary transition-colors">Training</a>
        <a href="#" className="hover:text-primary transition-colors">Community</a>
        <a href="#" className="hover:text-primary transition-colors">Shop</a>
      </div>
    </div>
    <div className="flex items-center gap-4">
      <button className="p-2 hover:bg-surface-bright rounded-full transition-colors">
        <Search size={20} />
      </button>
      <button className="p-2 hover:bg-surface-bright rounded-full transition-colors">
        <ShoppingBag size={20} />
      </button>
      <div className="w-10 h-10 rounded-full bg-surface-container-high border border-primary/20 overflow-hidden">
        <img src="https://picsum.photos/seed/user/100/100" alt="Avatar" referrerPolicy="no-referrer" />
      </div>
    </div>
  </nav>
);

const StatCard = ({ icon: Icon, label, value, unit, colorClass }: any) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="bg-surface-container-high p-8 rounded-xl relative overflow-hidden group"
  >
    <div className={`absolute top-0 right-0 w-32 h-32 -mr-8 -mt-8 rounded-full opacity-5 blur-3xl ${colorClass}`} />
    <div className="flex justify-between items-start mb-8">
      <div className={`p-3 rounded-2xl ${colorClass} bg-opacity-10 text-primary`}>
        <Icon size={24} />
      </div>
      <TrendingUp size={16} className="text-primary opacity-40" />
    </div>
    <p className="text-white/40 text-sm font-medium mb-1 uppercase tracking-widest">{label}</p>
    <div className="flex items-baseline gap-2">
      <h2 className="font-display text-5xl font-bold tracking-tight">{value}</h2>
      <span className="text-white/40 font-medium">{unit}</span>
    </div>
  </motion.div>
);

const LeaderboardRow = ({ rank, name, score, avatar }: any) => (
  <motion.div 
    whileHover={{ backgroundColor: "var(--color-surface-bright)" }}
    className="flex items-center justify-between p-6 rounded-2xl transition-colors group cursor-pointer"
  >
    <div className="flex items-center gap-6">
      <span className="font-display text-2xl font-bold text-white/20 w-8">{rank}</span>
      <div className="relative">
        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-outline-variant group-hover:border-primary transition-colors">
          <img src={avatar} alt={name} referrerPolicy="no-referrer" />
        </div>
        {rank === 1 && (
          <div className="absolute -top-1 -right-1 bg-primary text-surface p-1 rounded-full">
            <Trophy size={10} />
          </div>
        )}
      </div>
      <span className="font-display text-xl font-medium group-hover:text-primary transition-colors">{name}</span>
    </div>
    <div className="flex items-center gap-2">
      <span className="font-display text-2xl font-bold">{score}</span>
      <span className="text-white/40 text-xs uppercase tracking-widest">pts</span>
    </div>
  </motion.div>
);

const ProductCard = ({ name, price, image, category }: any) => (
  <motion.div 
    whileHover={{ y: -8 }}
    className="bg-surface-container rounded-xl overflow-hidden group"
  >
    <div className="aspect-square bg-surface-container-high relative overflow-hidden">
      <img 
        src={image} 
        alt={name} 
        className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
        referrerPolicy="no-referrer" 
      />
      <button className="absolute bottom-4 right-4 w-12 h-12 rounded-full gradient-primary glow-primary flex items-center justify-center text-surface opacity-0 group-hover:opacity-100 transition-all transform translate-y-4 group-hover:translate-y-0">
        <Plus size={24} />
      </button>
    </div>
    <div className="p-6">
      <p className="text-primary text-xs font-bold uppercase tracking-widest mb-2">{category}</p>
      <h3 className="font-display text-xl font-bold mb-4">{name}</h3>
      <p className="font-display text-2xl font-bold text-primary">${price}</p>
    </div>
  </motion.div>
);

export default function App() {
  return (
    <div className="min-h-screen pb-20">
      <Nav />
      
      <main className="max-w-7xl mx-auto px-6 pt-32">
        {/* Hero Section */}
        <section className="mb-20">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row justify-between items-end gap-8"
          >
            <div className="max-w-2xl">
              <h2 className="font-display text-7xl md:text-9xl font-bold tracking-tighter leading-[0.85] mb-8">
                PUSH <br />
                <span className="text-primary">BEYOND.</span>
              </h2>
              <p className="text-white/60 text-lg max-w-md leading-relaxed">
                Your performance data, refined. Track every heartbeat, every step, and every achievement with surgical precision.
              </p>
            </div>
            <div className="flex gap-4">
              <div className="flex -space-x-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-12 h-12 rounded-full border-2 border-surface bg-surface-container-high overflow-hidden">
                    <img src={`https://picsum.photos/seed/user${i}/100/100`} alt="User" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
              <div className="text-right">
                <p className="text-primary font-bold text-xl">+1.2k</p>
                <p className="text-white/40 text-xs uppercase tracking-widest">Active Now</p>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Stats Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-24">
          <StatCard 
            icon={Activity} 
            label="Daily Steps" 
            value="12,482" 
            unit="/ 15k" 
            colorClass="bg-primary"
          />
          <StatCard 
            icon={Flame} 
            label="Calories Burned" 
            value="1,840" 
            unit="kcal" 
            colorClass="bg-orange-500"
          />
          <StatCard 
            icon={Heart} 
            label="Heart Rate" 
            value="72" 
            unit="bpm" 
            colorClass="bg-red-500"
          />
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Leaderboard Section */}
          <section className="lg:col-span-7">
            <div className="flex items-center justify-between mb-10">
              <h3 className="font-display text-4xl font-bold tracking-tight">Leaderboard</h3>
              <button className="text-primary text-sm font-bold flex items-center gap-2 hover:gap-3 transition-all">
                VIEW ALL <ChevronRight size={16} />
              </button>
            </div>
            <div className="space-y-2">
              <LeaderboardRow 
                rank={1} 
                name="Alex Rivera" 
                score="12,450" 
                avatar="https://picsum.photos/seed/alex/100/100" 
              />
              <LeaderboardRow 
                rank={2} 
                name="Sarah Chen" 
                score="11,820" 
                avatar="https://picsum.photos/seed/sarah/100/100" 
              />
              <LeaderboardRow 
                rank={3} 
                name="Marcus Thorne" 
                score="10,940" 
                avatar="https://picsum.photos/seed/marcus/100/100" 
              />
              <LeaderboardRow 
                rank={4} 
                name="Elena Vance" 
                score="9,720" 
                avatar="https://picsum.photos/seed/elena/100/100" 
              />
            </div>
          </section>

          {/* Training Focus Section */}
          <section className="lg:col-span-5">
            <div className="bg-surface-container-low rounded-xl p-10 h-full relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 blur-[100px] -mr-32 -mt-32" />
              <h3 className="font-display text-3xl font-bold mb-8 relative z-10">Training Focus</h3>
              <div className="space-y-8 relative z-10">
                <div>
                  <div className="flex justify-between mb-3">
                    <span className="font-medium">Endurance</span>
                    <span className="text-primary">85%</span>
                  </div>
                  <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: "85%" }}
                      transition={{ duration: 1, delay: 0.5 }}
                      className="h-full gradient-primary" 
                    />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-3">
                    <span className="font-medium">Strength</span>
                    <span className="text-primary">62%</span>
                  </div>
                  <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: "62%" }}
                      transition={{ duration: 1, delay: 0.7 }}
                      className="h-full gradient-primary" 
                    />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-3">
                    <span className="font-medium">Flexibility</span>
                    <span className="text-primary">45%</span>
                  </div>
                  <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: "45%" }}
                      transition={{ duration: 1, delay: 0.9 }}
                      className="h-full gradient-primary" 
                    />
                  </div>
                </div>
              </div>
              <button className="mt-12 w-full py-4 rounded-full border border-primary/20 text-primary font-bold hover:bg-primary hover:text-surface transition-all uppercase tracking-widest text-sm">
                Customize Plan
              </button>
            </div>
          </section>
        </div>

        {/* Shop Section */}
        <section className="mt-32">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h3 className="font-display text-4xl font-bold tracking-tight mb-2 text-primary">Performance Gear</h3>
              <p className="text-white/40">Engineered for the elite.</p>
            </div>
            <button className="px-8 py-3 rounded-full bg-surface-container-high border border-outline-variant font-bold hover:bg-surface-bright transition-colors">
              SHOP ALL
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <ProductCard 
              name="Kinetic Pro Runner" 
              price="180.00" 
              category="Footwear"
              image="https://picsum.photos/seed/shoe1/400/400"
            />
            <ProductCard 
              name="Carbon Tech Tee" 
              price="65.00" 
              category="Apparel"
              image="https://picsum.photos/seed/shirt1/400/400"
            />
            <ProductCard 
              name="Pulse Smart Band" 
              price="120.00" 
              category="Tech"
              image="https://picsum.photos/seed/watch1/400/400"
            />
            <ProductCard 
              name="Hydra Elite Bottle" 
              price="45.00" 
              category="Accessories"
              image="https://picsum.photos/seed/bottle1/400/400"
            />
          </div>
        </section>
      </main>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-6 left-6 right-6 h-16 glass rounded-full border border-outline-variant flex items-center justify-around px-4 z-50">
        <button className="p-2 text-primary"><Activity size={24} /></button>
        <button className="p-2 text-white/40"><Flame size={24} /></button>
        <button className="p-2 text-white/40"><ShoppingBag size={24} /></button>
        <button className="p-2 text-white/40"><User size={24} /></button>
      </div>
    </div>
  );
}
