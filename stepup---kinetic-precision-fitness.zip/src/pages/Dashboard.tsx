import React from 'react';
import { motion } from 'motion/react';

export default function Dashboard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-10"
    >
      {/* Hero Bento Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Circular Progress Gauge */}
        <div className="lg:col-span-2 bg-surface-container-low p-8 rounded-[2rem] relative overflow-hidden group border border-white/5 shadow-2xl">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-10">
            <div className="space-y-4">
              <h2 className="font-headline text-4xl font-black tracking-tighter uppercase text-primary">今日动力</h2>
              <p className="text-on-surface-variant max-w-xs">你今天正在挑战极限。在中午之前已完成每日目标的 84%。</p>
              <div className="flex gap-4">
                <div className="bg-surface-container-high px-4 py-2 rounded-xl border border-secondary/10">
                  <p className="text-[10px] uppercase tracking-widest text-secondary font-bold">当前</p>
                  <p className="font-headline text-2xl font-bold">12,482</p>
                </div>
                <div className="bg-surface-container-high px-4 py-2 rounded-xl border border-primary/10">
                  <p className="text-[10px] uppercase tracking-widest text-on-surface-variant font-bold">目标</p>
                  <p className="font-headline text-2xl font-bold text-on-surface-variant">15,000</p>
                </div>
              </div>
            </div>
            <div className="relative w-64 h-64 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  className="text-surface-container-highest"
                  cx="128"
                  cy="128"
                  fill="transparent"
                  r="110"
                  stroke="currentColor"
                  strokeWidth="24"
                />
                <motion.circle
                  initial={{ strokeDashoffset: 691 }}
                  animate={{ strokeDashoffset: 691 - (691 * 0.84) }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="text-primary"
                  cx="128"
                  cy="128"
                  fill="transparent"
                  r="110"
                  stroke="currentColor"
                  strokeDasharray="691"
                  strokeLinecap="round"
                  strokeWidth="24"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="font-headline text-5xl font-black italic">84%</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">已完成</span>
              </div>
            </div>
          </div>
          {/* Decorative background element */}
          <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-primary/5 blur-[100px] rounded-full"></div>
        </div>

        {/* Cumulative Stats Micro-Cards */}
        <div className="flex flex-col gap-6">
          {[
            { label: '总里程', value: '9.42', unit: '公里', icon: 'route', color: 'text-secondary', bg: 'bg-secondary/10' },
            { label: '消耗卡路里', value: '842', unit: '千卡', icon: 'local_fire_department', color: 'text-error', bg: 'bg-error/10' },
            { label: '活跃时间', value: '1小时 42', unit: '分', icon: 'timer', color: 'text-tertiary', bg: 'bg-tertiary/10' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-surface-container-low p-6 rounded-[2rem] flex items-center justify-between group hover:bg-surface-container-high transition-all border border-white/5"
            >
              <div>
                <p className={cn("text-xs font-bold uppercase tracking-widest mb-1", stat.color)}>{stat.label}</p>
                <h3 className="font-headline text-3xl font-black">
                  {stat.value}<span className="text-sm font-normal ml-1">{stat.unit}</span>
                </h3>
              </div>
              <div className={cn("w-12 h-12 rounded-full flex items-center justify-center", stat.bg, stat.color)}>
                <span className="material-symbols-outlined fill-1">{stat.icon}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Chart Section (Trends) */}
      <section className="space-y-6">
        <div className="flex justify-between items-end">
          <div>
            <h2 className="font-headline text-2xl font-bold tracking-tight uppercase">运动趋势</h2>
            <p className="text-on-surface-variant">过去 7 天的步数稳定性</p>
          </div>
          <div className="flex bg-surface-container-high p-1 rounded-full border border-white/5">
            <button className="px-4 py-1.5 text-xs font-bold rounded-full bg-primary text-[#3a4a00] shadow-sm">每周</button>
            <button className="px-4 py-1.5 text-xs font-bold text-on-surface-variant hover:text-on-surface">每月</button>
          </div>
        </div>
        <div className="bg-surface-container-low p-8 rounded-[2rem] h-80 flex items-end gap-3 md:gap-6 relative border border-white/5">
          {[
            { day: '周一', val: '45%', label: '8.2k' },
            { day: '周二', val: '70%', label: '12.1k' },
            { day: '周三', val: '95%', label: '16.8k', active: true },
            { day: '周四', val: '60%', label: '10.5k' },
            { day: '周五', val: '55%', label: '9.8k' },
            { day: '周六', val: '85%', label: '14.9k' },
            { day: '周日', val: '40%', label: '7.2k' },
          ].map((bar, i) => (
            <div key={bar.day} className="flex-1 flex flex-col items-center group cursor-pointer h-full justify-end">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: bar.val }}
                transition={{ delay: i * 0.05, duration: 0.8, ease: "easeOut" }}
                className={cn(
                  "w-full rounded-full relative transition-all",
                  bar.active ? "bg-primary/20 border-2 border-primary/30" : "bg-surface-container-highest group-hover:bg-secondary/40"
                )}
              >
                <div className={cn(
                  "absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 rounded text-[10px] font-black transition-opacity",
                  bar.active ? "bg-primary text-[#3a4a00] opacity-100" : "bg-secondary text-[#003a42] opacity-0 group-hover:opacity-100"
                )}>
                  {bar.label}
                </div>
              </motion.div>
              <span className={cn(
                "mt-4 text-[10px] font-bold uppercase tracking-tighter",
                bar.active ? "text-primary" : "text-on-surface-variant"
              )}>
                {bar.day}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Milestones & Personal Bests */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary"></span>
            <h2 className="font-headline text-xl font-bold tracking-tight uppercase">近期里程碑</h2>
          </div>
          <div className="space-y-4">
            {[
              { title: '500公里俱乐部', desc: '昨天解锁 • 总距离', icon: 'military_tech', color: 'text-tertiary', bg: 'bg-tertiary/10' },
              { title: '7 天连续达标', desc: '2 天前解锁 • 稳定性', icon: 'bolt', color: 'text-secondary', bg: 'bg-secondary/10' },
            ].map((milestone) => (
              <div key={milestone.title} className="bg-surface-container-low p-5 rounded-2xl flex items-center gap-4 group hover:translate-x-2 transition-transform border border-white/5">
                <div className={cn("w-14 h-14 rounded-full flex items-center justify-center", milestone.bg, milestone.color)}>
                  <span className="material-symbols-outlined text-3xl fill-1">{milestone.icon}</span>
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-on-surface">{milestone.title}</h4>
                  <p className="text-xs text-on-surface-variant">{milestone.desc}</p>
                </div>
                <span className="material-symbols-outlined text-on-surface-variant">chevron_right</span>
              </div>
            ))}
          </div>
        </div>
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-secondary"></span>
            <h2 className="font-headline text-xl font-bold tracking-tight uppercase">个人最佳</h2>
          </div>
          <div className="bg-surface-container-low p-6 rounded-[2.5rem] relative overflow-hidden group border border-white/5 shadow-xl">
            <div className="relative z-10 space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-secondary">单日最高步数</p>
                  <p className="font-headline text-4xl font-black italic">28,492</p>
                </div>
                <span className="text-xs bg-secondary/10 text-secondary px-3 py-1 rounded-full font-bold">10月24日</span>
              </div>
              <div className="h-px bg-outline-variant/10 w-full"></div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">最长步行距离</p>
                  <p className="font-headline text-4xl font-black italic">18.4 <span className="text-xl">公里</span></p>
                </div>
                <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full font-bold">9月12日</span>
              </div>
            </div>
            {/* Background glow */}
            <div className="absolute -top-10 -right-10 w-48 h-48 bg-secondary/5 blur-[80px] rounded-full"></div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
