import React from 'react';
import { motion } from 'motion/react';

export default function Profile() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-12"
    >
      {/* Hero Bento Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Avatar Display Card */}
        <div className="lg:col-span-2 relative h-[500px] bg-surface-container-low rounded-[2.5rem] overflow-hidden flex flex-col items-center justify-center border border-white/5 shadow-2xl">
          <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 50% 50%, #00e3fd 0%, transparent 70%)" }}></div>
          <div className="relative z-10 w-full h-full flex flex-col items-center">
            {/* 2D Virtual Avatar Rendering */}
            <div className="mt-8 flex-1 flex items-center justify-center">
              <img
                alt="用户头像"
                className="h-[400px] object-contain drop-shadow-[0_20px_50px_rgba(243,255,202,0.3)]"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAPMZ6N6d9OPbP5afJaoyJKn1aNNit9A77AjSwhXjnEn5p_Vx_QRvhtzmS3hDToSAKL163GCbI5rNynd0mO4YGkSdcrhJY7tnFEvmUiJ3JiwmHDltQHaFEan8n5w9Xx0_SBfQTO0m6UaPddW9Yt4HR-3GV5HjY_aOiTfYA949j6yCwNuZRP8bUmC5fdVb6xef-35-J2Muarv_A7c6x_CVJOzrS6iG5UlE-gOUH5UpUcV017Soz4HgjbmdcsF6ykNYak8JymGAPRidKF"
              />
            </div>
            {/* Energy Points Floating Card */}
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 glass-panel p-4 rounded-full flex items-center gap-6 border border-white/10 shadow-2xl">
              <div className="flex flex-col items-center border-r border-white/10 pr-6">
                <span className="text-secondary text-[10px] font-bold uppercase tracking-widest">能量值</span>
                <span className="font-headline text-3xl font-black text-primary">12,480</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
                <span className="text-xs font-bold text-on-surface-variant italic">实时同步</span>
              </div>
            </div>
            {/* Customization Floating Quick Actions */}
            <div className="absolute top-8 right-8 flex flex-col gap-3">
              <button className="p-3 bg-surface-container-high rounded-full hover:bg-secondary hover:text-[#003a42] transition-all active:scale-90 border border-white/5">
                <span className="material-symbols-outlined">brush</span>
              </button>
              <button className="p-3 bg-surface-container-high rounded-full hover:bg-secondary hover:text-[#003a42] transition-all active:scale-90 border border-white/5">
                <span className="material-symbols-outlined">wallpaper</span>
              </button>
            </div>
          </div>
        </div>
        {/* Stats Quick View */}
        <div className="space-y-6">
          <div className="bg-surface-container-high p-8 rounded-[2rem] border border-white/5 shadow-xl">
            <div className="flex justify-between items-start mb-6">
              <span className="text-primary font-headline text-xl font-bold italic tracking-tighter uppercase">每日冲刺</span>
              <span className="material-symbols-outlined text-primary fill-1">bolt</span>
            </div>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-on-surface-variant font-bold uppercase">步数目标</span>
                  <span className="text-on-surface font-black">8,421 / 10k</span>
                </div>
                <div className="h-3 bg-surface-container w-full rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: '84%' }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className="h-full kinetic-gradient"
                  />
                </div>
              </div>
              <div className="pt-4 grid grid-cols-2 gap-4">
                <div className="bg-surface-container-low p-4 rounded-2xl border border-white/5">
                  <p className="text-[10px] text-on-surface-variant font-bold uppercase">卡路里</p>
                  <p className="text-xl font-headline font-black">420</p>
                </div>
                <div className="bg-surface-container-low p-4 rounded-2xl border border-white/5">
                  <p className="text-[10px] text-on-surface-variant font-bold uppercase">时长</p>
                  <p className="text-xl font-headline font-black">42m</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-secondary/5 p-8 rounded-[2rem] border border-secondary/20 relative overflow-hidden shadow-xl">
            <div className="relative z-10">
              <p className="text-secondary font-headline text-lg font-bold mb-2 uppercase">联赛状态</p>
              <p className="text-on-surface text-2xl font-black italic">钻石段位</p>
              <p className="text-on-surface-variant text-xs mt-2 italic">本周排名前 3% 的运动员</p>
            </div>
            <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-secondary/10 text-9xl fill-1">emoji_events</span>
          </div>
        </div>
      </div>

      {/* Achievement Section */}
      <section>
        <div className="flex justify-between items-end mb-8">
          <h2 className="font-headline text-3xl font-black text-on-surface tracking-tighter uppercase">成就徽章</h2>
          <button className="text-secondary text-sm font-bold border-b border-secondary/30 pb-1 hover:text-primary transition-colors">查看收藏</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { title: '头号行者', desc: '累计 100万 步', icon: 'workspace_premium', color: 'text-primary', bg: 'bg-primary/20' },
            { title: '音爆', desc: '45分钟内完成 10公里', icon: 'speed', color: 'text-secondary', bg: 'bg-secondary/20' },
            { title: '铁肺', desc: '连续坚持 30 天', icon: 'local_fire_department', color: 'text-tertiary', bg: 'bg-tertiary/20' },
          ].map((badge) => (
            <div key={badge.title} className="group bg-surface-container-low p-6 rounded-[2rem] border border-white/5 hover:border-primary/30 transition-all text-center shadow-lg">
              <div className="w-20 h-20 mx-auto mb-4 relative">
                <div className={cn("absolute inset-0 blur-xl group-hover:scale-125 transition-all", badge.bg)}></div>
                <span className={cn("material-symbols-outlined text-5xl relative z-10 fill-1", badge.color)}>{badge.icon}</span>
              </div>
              <p className="text-xs font-bold text-on-surface tracking-wide uppercase mb-1">{badge.title}</p>
              <p className="text-[10px] text-on-surface-variant">{badge.desc}</p>
            </div>
          ))}
          <div className="group bg-surface-container-low p-6 rounded-[2rem] border border-white/5 border-dashed text-center flex flex-col items-center justify-center opacity-60">
            <span className="material-symbols-outlined text-4xl text-on-surface-variant mb-2">lock</span>
            <p className="text-[10px] text-on-surface-variant font-bold uppercase">神秘勋章</p>
          </div>
        </div>
      </section>

      {/* Layout & Customization Bento Row */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12">
        <div className="bg-surface-container-high rounded-[2.5rem] p-8 border border-white/5 shadow-xl">
          <h3 className="font-headline text-xl font-bold mb-6 flex items-center gap-3 uppercase">
            <span className="material-symbols-outlined text-primary fill-1">palette</span> 主题引擎
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {['#f3ffca', '#00e3fd', '#ffeea5', '#ff7351', '#292c31'].map((color, i) => (
              <button key={color} className={cn("aspect-square rounded-2xl bg-background border-2 flex items-center justify-center transition-all active:scale-90", i === 0 ? "border-primary" : "border-transparent hover:border-white/20")}>
                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: color }}></div>
              </button>
            ))}
            <button className="aspect-square rounded-2xl bg-surface-container flex items-center justify-center border-2 border-white/5 hover:bg-white/5 transition-all">
              <span className="material-symbols-outlined text-on-surface-variant">add</span>
            </button>
          </div>
        </div>
        <div className="bg-surface-container-high rounded-[2.5rem] p-8 border border-white/5 flex flex-col justify-between shadow-xl">
          <div>
            <h3 className="font-headline text-xl font-bold mb-2 flex items-center gap-3 uppercase">
              <span className="material-symbols-outlined text-secondary fill-1">grid_view</span> 界面布局
            </h3>
            <p className="text-on-surface-variant text-sm mb-6">选择如何在主面板上优先展示您的运动数据。</p>
          </div>
          <div className="flex gap-4">
            <div className="flex-1 p-4 rounded-2xl bg-background border border-primary/40 flex flex-col gap-2 shadow-inner">
              <div className="h-2 w-full bg-primary/20 rounded"></div>
              <div className="h-8 w-full bg-primary/40 rounded"></div>
              <div className="flex gap-2">
                <div className="h-4 flex-1 bg-primary/20 rounded"></div>
                <div className="h-4 flex-1 bg-primary/20 rounded"></div>
              </div>
              <p className="text-[10px] text-center font-bold text-primary mt-1 uppercase">性能模式</p>
            </div>
            <div className="flex-1 p-4 rounded-2xl bg-background border border-white/5 flex flex-col gap-2 opacity-40 grayscale">
              <div className="h-8 w-full bg-white/5 rounded"></div>
              <div className="h-2 w-full bg-white/5 rounded"></div>
              <div className="h-2 w-full bg-white/5 rounded"></div>
              <p className="text-[10px] text-center font-bold text-on-surface-variant mt-1 uppercase">社交模式</p>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
